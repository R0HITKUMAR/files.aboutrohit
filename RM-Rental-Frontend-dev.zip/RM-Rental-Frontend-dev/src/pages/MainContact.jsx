
import Contact from '../components/Contact'

const MainContact = () => {
  return (
    <div>
      <Contact/>
    </div>
  )
}

export default MainContact
