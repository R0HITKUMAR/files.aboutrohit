
const UserEvents = () => {
  return (
    <div>
      <h1>User Events</h1>
    </div>
  )
}

export default UserEvents
