/* eslint-disable no-unused-vars */
import React from 'react'

const PrivateRoute = () => {
  return (
    <div>
      
    </div>
  )
}

export default PrivateRoute
