
const Updateform = () => {
  return (
    <div>
      <h1>Update</h1>
    </div>
  )
}

export default Updateform
