/* eslint-disable no-unused-vars */
import React from 'react'

const Createblog = () => {
  return (
    <div>
      <h1>Create Blog</h1>
    </div>
  )
}

export default Createblog
