/* eslint-disable no-unused-vars */
import React from 'react'

const OrderDetails = () => {
  return (
    <div>
      <h1>Order Details</h1>
    </div>
  )
}

export default OrderDetails
