
const Coupon = () => {
  return (
    <div>
      <h1>Coupon</h1>
    </div>
  )
}

export default Coupon
