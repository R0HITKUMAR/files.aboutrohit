
const Approve = () => {
  return (
    <div>
      <h1>Approve</h1>
    </div>
  )
}

export default Approve
