
const Categories = () => {
  return (
    <div>
      <h1>Categories</h1>
    </div>
  )
}

export default Categories
